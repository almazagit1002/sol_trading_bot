"""
Provides a pure-Python HTTP/2 framing layer.
"""
from __future__ import annotations

__version__ = "6.1.0"
